#ifndef RACER_1
#define RACER_1

#include "racer.h"

class Racer_1 : public Racer{

};

#endif
